﻿//Day03 Task:
//part01: 
// Problem01 : 
using Microsoft.VisualBasic;
using System;
using System.Text;
using System.Threading.Channels;
using static System.Runtime.InteropServices.JavaScript.JSType;

class Program
{
    static void Main()
    {
        Console.Write("Enter a string to convert to an integer: ");
        string userInput = Console.ReadLine();

        try
        {
            int parsedValue = int.Parse(userInput);
            Console.WriteLine("Value using int.Parse: " + parsedValue);
        }
        catch (FormatException ex)
        {
            Console.WriteLine("Error using int.Parse: " + ex.Message);
        }
        catch (ArgumentNullException ex)
        {
            Console.WriteLine("Error using int.Parse: " + ex.Message);
        }

        try
        {
            int convertedValue = Convert.ToInt32(userInput);
            Console.WriteLine("Value using Convert.ToInt32: " + convertedValue);
        }
        catch (FormatException ex)
        {
            Console.WriteLine("Error using Convert.ToInt32: " + ex.Message);
        }
        catch (ArgumentNullException ex)
        {
            Console.WriteLine("Error using Convert.ToInt32: " + ex.Message);
        }
    }
}


//Question : 
// the key difference is how null is handled:

// int.Parse will throw an ArgumentNullException when null is passed.
// Convert.ToInt32 will return 0 when null is passed, instead of throwing an exception.
//--------------------------------------------------------------------------------------------------//

//>> problem02: 
using System;

class Program
{
    static void Main()
    {
        // Prompt the user for input
        Console.Write("Enter a number: ");
        string userInput = Console.ReadLine();

        // Try to parse the input using int.TryParse
        if (int.TryParse(userInput, out int parsedValue))
        {
            // If valid, print the number
            Console.WriteLine("You entered the valid number: " + parsedValue);
        }
        else
        {
            // If invalid, print an error message
            Console.WriteLine("Error: The input is not a valid integer.");
        }
    }
}
//question:
//TryParse is preferred because it prevents exceptions and provides a clean way to
//validate user input, making the application more reliable and user-friendly.
//-------------------------------------------------------------------------------------------------------------//

//>> problem03: 
using System;

class Program
{
    static void Main()
    {
        object obj;

        obj = 42;
        Console.WriteLine($"Value: {obj}, GetHashCode: {obj.GetHashCode()}");

        obj = "Hello, World!";
        Console.WriteLine($"Value: {obj}, GetHashCode: {obj.GetHashCode()}");

        obj = 3.14159;
        Console.WriteLine($"Value: {obj}, GetHashCode: {obj.GetHashCode()}");
    }
}
//question : 
//In summary, GetHashCode() is used to improve the performance of operations that involve 
//searching, inserting, and comparing objects, especially in collections like Dictionary and HashSet
//----------------------------------------------------------------------------------//

//>> problem 04: 
using System;

class Program
{
    static void Main()
    {
        MyClass obj1 = new MyClass();
        obj1.Value = 42;
        Console.WriteLine($"Initial value from obj1: {obj1.Value}");

        MyClass obj2 = obj1;

        obj1.Value = 100;

        Console.WriteLine($"Value from obj2 after modification: {obj2.Value}");
    }
}

class MyClass
{
    public int Value { get; set; }
}

//question: 
//Reference equality checks if two references point to the same memory location (i.e., the same object).
//Changes to an object via one reference affect all references pointing to that object.
//Understanding reference equality is important for managing memory and object manipulation in object-oriented programming in .NET.
//--------------------------------------------------------------------------------------------//

//>> problem 05: 
using System;

class Program
{
    static void Main()
    {
        string str = "Hello";

        Console.WriteLine($"Before modification: {str}, GetHashCode: {str.GetHashCode()}");

        str = str + " Hi Willy";

        Console.WriteLine($"After modification: {str}, GetHashCode: {str.GetHashCode()}");
    }
}
//question: 
//Immutability ensures strings are thread-safe, secure, and memory-efficient.
//Any modification to a string creates a new string rather than modifying the existing one.
//This property is fundamental for ensuring the reliability and consistency of strings in C#.
//--------------------------------------------------------------------------------//

//>>problem 06: 
using System;
using System.Text;

class Program
{
    static void Main()
    {
        StringBuilder sb = new StringBuilder("Hi Willy");


        Console.WriteLine($"Before modification: {sb.ToString()}, GetHashCode: {sb.GetHashCode()}");

        sb.Append(" - Welcome!");

        Console.WriteLine($"After modification: {sb.ToString()}, GetHashCode: {sb.GetHashCode()}");
    }
}

// >>question1: 
//StringBuilder improves performance and memory efficiency by modifying a mutable buffer, reducing the need for repeated string allocations.
//It is particularly useful in scenarios where multiple string modifications are needed, such as in loops or when concatenating large amounts of text.
//String concatenation with + is inefficient for frequent modifications due to the creation of intermediate string objects, while StringBuilder avoids this problem with its internal buffer management.
//>>question2: 
//StringBuilder is faster for large-scale string modifications because it:
//Avoids creating new strings for every modification, reducing the overhead of repeated memory allocations and copies.
//Modifies a mutable internal buffer, efficiently appending data.
//Minimizes reallocations by dynamically growing the buffer in chunks, making it ideal for scenarios with frequent string changes. This makes StringBuilder the preferred choice for
//scenarios where you need to perform a large number of string manipulations, like building strings in loops or complex string concatenations.

//----------------------------------------------------------------------------------------//

//>> problem07: 
using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter the first integer: ");
        int input1 = int.Parse(Console.ReadLine());

        Console.Write("Enter the second integer: ");
        int input2 = int.Parse(Console.ReadLine());

        int sum = input1 + input2;

        Console.WriteLine("Using Concatenation: Sum is " + input1 + " + " + input2 + " = " + sum);

        Console.WriteLine("Using Composite Formatting: Sum is {0} + {1} = {2}", input1, input2, sum);

        Console.WriteLine($"Using String Interpolation: Sum is {input1} + {input2} = {sum}");
    }
}
// question: 
//While string.Format and concatenation are still useful in certain scenarios (e.g., older C# versions or 
//when compatibility is needed), string interpolation is generally the preferred choice in modern C# because of its readability, ease of use, and efficiency.
//------------------------------------------------------------------------//

//>>  problem08:
using System;
using System.Text;

class Program
{
    static void Main()
    {
        StringBuilder sb = new StringBuilder("Hello, World!");

        sb.Append(" How are you?");
        Console.WriteLine("After Append: " + sb.ToString());

        sb.Replace("World", "CSharp");
        Console.WriteLine("After Replace: " + sb.ToString());

        sb.Insert(13, " - Welcome");
        Console.WriteLine("After Insert: " + sb.ToString());

        sb.Remove(13, 8); 
        Console.WriteLine("After Remove: " + sb.ToString());
    }
}

// question : 
//StringBuilder uses a mutable internal buffer, making it much more efficient for frequent string modifications.
//It avoids the overhead of creating new strings and reallocating memory for each modification.
//It’s designed to handle scenarios like appending, inserting, replacing, and removing text, without the performance penalties of immutable strings.
//-----------------------------------------------------------------------------------//













